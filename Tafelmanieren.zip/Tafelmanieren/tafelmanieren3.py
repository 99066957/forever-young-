for i in range(0,12 ):
    print(str(i)+ ":00" + " AM")
for i in range(0,12 ):
    print(str(i)+ ":00" + " PM")
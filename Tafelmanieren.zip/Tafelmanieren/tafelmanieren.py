for i in range (4,41,4):
    print(i)
